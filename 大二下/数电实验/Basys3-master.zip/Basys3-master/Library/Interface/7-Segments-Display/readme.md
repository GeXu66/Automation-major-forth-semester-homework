This interface IP displays either a 16-bit or 32-bit input, consists of either 4 or 8 nibbles data, 
on either one or two modules having 4 7-segments displays each.
