This interface IP generates a pulse width modulated output.
