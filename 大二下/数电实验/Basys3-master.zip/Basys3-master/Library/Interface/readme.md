This directory containts several interface IPs which can be used with the Basys3 board. Each IP is stored in an individual directory. 
In order to use the desired IP(s) download the directory and place it in some repository. While creating design, you can point the 
IP repository path to point it to directory where you have placed the directories. 

Please read the readme.txt file located under the doc sub-directoy of the corresponding IP to understand its functionality and
how to use it.
